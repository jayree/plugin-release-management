import { PutObjectCommandOutput } from '@aws-sdk/client-s3';
export declare function putObject(bucket: string, key: string, body: string): Promise<PutObjectCommandOutput>;
