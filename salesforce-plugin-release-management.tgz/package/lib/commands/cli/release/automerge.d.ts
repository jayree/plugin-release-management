import { SfCommand } from '@salesforce/sf-plugins-core';
/**
 * Bot accounts whose PRs are eligible for automerge. Add to this list (via
 * reviewed PR) to onboard a new bot.
 */
export declare const ALLOWED_BOT_USERS: string[];
export declare function isAllowedBotUser(login: string | undefined | null): boolean;
export default class AutoMerge extends SfCommand<void> {
    static readonly summary: string;
    static readonly description: string;
    static readonly examples: string[];
    static readonly flags: {
        owner: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
        repo: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
        'pull-number': import("@oclif/core/interfaces").OptionFlag<number, import("@oclif/core/interfaces").CustomOptions>;
        'dry-run': import("@oclif/core/interfaces").BooleanFlag<boolean>;
        verbose: import("@oclif/core/interfaces").BooleanFlag<boolean>;
    };
    private octokit;
    private baseRepoParams;
    private pullRequestParams;
    run(): Promise<void>;
    private isGreen;
    private isMergeable;
}
