import { _Object, GetObjectRequest, GetObjectOutput } from '@aws-sdk/client-s3';
import { AwsCredentialIdentity } from '@smithy/types';
import { Channel, CLI, S3Manifest, ServiceAvailability } from './types.js';
type GetObjectOption = Omit<GetObjectRequest, 'Bucket'>;
type AmazonS3Options = {
    bucket?: string;
    cli: CLI;
    channel?: Channel;
    baseUrl?: string;
    credentials?: AwsCredentialIdentity;
    baseKey?: string;
};
export declare class AmazonS3 {
    private options;
    static STATUS_URL: string;
    directory: string;
    private s3;
    private readonly baseKey;
    constructor(options: AmazonS3Options);
    ping(): Promise<ServiceAvailability>;
    getManifestFromChannel(channel: string): Promise<S3Manifest>;
    getObject(options: GetObjectOption): Promise<GetObjectOutput>;
    listAllObjects(key: string): Promise<{
        contents: _Object[];
        commonPrefixes: string[];
    }>;
    listCommonPrefixes(key: string): Promise<string[]>;
    listKeyContents(key: string): Promise<_Object[]>;
}
export declare const download: (url: string, location: string, silent?: boolean) => Promise<void>;
export {};
