export declare class Registry {
  registryUrl?: string | undefined;
  authToken?: string | undefined;
  registryEntryLocal: string;
  registryEntryGlobal: string;
  private env;
  constructor(registryUrl?: string | undefined, authToken?: string | undefined);
  /**
   * Return a properly formatted --registry string
   */
  getRegistryParameter(): string;
  /**
   * Compare this.registryUrl against npm configs and write registry entry "registry" entry to <packageDir>/.npmrc
   * if either is not equal
   *
   * @param packageDirectory
   */
  setNpmRegistry(packageDirectory: string): Promise<void>;
  /**
   * Examine the current npm configs to see if the registry has
   * the authToken set.
   * If not write the authToken to <packageDir>/.npmrc
   *
   * @param packageDirectory
   */
  setNpmAuth(packageDirectory: string): Promise<void>;
  loadNpmConfigs(): void;
  readNpmrc(packageDir: string): Promise<string[]>;
  writeNpmrc(packageDir: string, npmrc: string[]): Promise<void>;
  private normalizeRegistryUrl;
}
