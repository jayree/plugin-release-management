export declare enum CLI {
    SF = "sf",
    SFDX = "sfdx"
}
export declare enum Channel {
    LEGACY = "legacy",
    STABLE = "stable",
    STABLE_RC = "stable-rc",
    LATEST = "latest",
    LATEST_RC = "latest-rc"
}
export type S3Manifest = {
    version: string;
    sha: string;
    baseDir: string;
    gz: string;
    xz: string;
    sha256gz: string;
    sha256xz: string;
    node: {
        compatible: string;
        recommended: string;
    };
};
export type ServiceAvailability = {
    service: string;
    name?: string;
    available: boolean;
};
export type VersionShaContents = {
    Key: string;
    LastModified: string;
    LastModifiedDate: Date;
    ETag: string;
    Size: number;
    StorgaeClass: string;
};
