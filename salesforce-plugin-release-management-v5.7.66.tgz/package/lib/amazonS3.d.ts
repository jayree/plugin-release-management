import { S3 } from 'aws-sdk';
import { CredentialsOptions } from 'aws-sdk/lib/credentials.js';
import { GetObjectRequest, GetObjectOutput } from 'aws-sdk/clients/s3.js';
import { Channel, CLI, S3Manifest, ServiceAvailability } from './types.js';
type GetObjectOption = Omit<GetObjectRequest, 'Bucket'>;
type AmazonS3Options = {
  bucket?: string;
  cli: CLI;
  channel?: Channel;
  baseUrl?: string;
  credentials?: CredentialsOptions;
  baseKey?: string;
};
export declare class AmazonS3 {
  private options;
  static STATUS_URL: string;
  directory: string;
  private s3;
  private baseKey;
  constructor(options: AmazonS3Options);
  ping(): Promise<ServiceAvailability>;
  getManifestFromChannel(channel: string): Promise<S3Manifest>;
  getObject(options: GetObjectOption): Promise<GetObjectOutput>;
  listAllObjects(key: string): Promise<{
    contents: S3.ObjectList;
    commonPrefixes: string[];
  }>;
  listCommonPrefixes(key: string): Promise<string[]>;
  listKeyContents(key: string): Promise<S3.ObjectList>;
}
export declare const download: (url: string, location: string, silent?: boolean) => Promise<void>;
export {};
