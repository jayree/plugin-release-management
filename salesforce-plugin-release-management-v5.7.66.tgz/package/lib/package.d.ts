import { AsyncOptionalCreatable } from '@salesforce/kit';
import { AnyJson } from '@salesforce/ts-types';
export type PackageJson = {
  name: string;
  version: string;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
  scripts: Record<string, string>;
  files?: string[];
  pinnedDependencies?: string[];
  resolutions?: Record<string, string>;
  repository?: string;
  homepage?: string;
  sfdx?: PackageJsonSfdxProperty;
  oclif?: {
    plugins?: string[];
    devPlugins?: string[];
    jitPlugins?: Record<string, string>;
  };
} & AnyJson;
export type PackageJsonSfdxProperty = {
  publicKeyUrl: string;
  signatureUrl: string;
};
export type ChangedPackageVersions = Array<{
  name: string;
  version: string;
  tag: string;
}>;
export type NpmPackage = {
  name: string;
  version: string;
  versions: string[];
  'dist-tags': Record<string, string>;
  time?: Record<string, string>;
} & Partial<PackageJson>;
export type VersionValidation = {
  nextVersion: string;
  currentVersion: string;
  valid: boolean;
  name: string;
};
type PinnedPackage = {
  name: string;
  version: string;
  tag: string;
};
type DependencyInfo = {
  packageName: string;
  currentVersion?: string;
  finalVersion?: string;
};
export declare function parsePackageVersion(alias: string): string | undefined;
export declare class Package extends AsyncOptionalCreatable {
  name: string;
  npmPackage: NpmPackage;
  packageJson: PackageJson;
  location: string;
  private registry;
  constructor(
    opts:
      | {
          location?: string;
        }
      | undefined
  );
  readPackageJson(): Promise<PackageJson>;
  /**
   * Retrieve the npm package info using `npm view`
   *
   * It'll first try to find the package with the version listed in the package.json
   * If that version doesn't exist, it'll find the version tagged as latest
   */
  retrieveNpmPackage(): NpmPackage | undefined;
  nextVersionIsAvailable(nextVersion: string): boolean;
  writePackageJson(rootDir?: string): void;
  calculatePinnedPackageUpdates(pinnedPackages: PinnedPackage[]): PinnedPackage[];
  getDistTags(name: string): Record<string, string>;
  bumpResolutions(tag: string): Record<string, string>;
  /**
   * Lookup dependency info by package name
   * Examples: @salesforce/plugin-info
   * Pass in the dependencies you want to search through (dependencies, devDependencies, resolutions, etc)
   */
  getDependencyInfo(name: string, dependencies: Record<string, string>): DependencyInfo;
  bumpDependencyVersions(targetDependencies: string[]): DependencyInfo[];
  determineNextVersion(isPatch?: boolean, prerelease?: string): string;
  pinDependencyVersions(targetTag: string): ChangedPackageVersions;
  bumpJit(targetTag?: string): ChangedPackageVersions | undefined;
  /**
   * Returns true if the version specified in the package.json has not been
   * published to the registry
   */
  nextVersionIsHardcoded(): boolean;
  hasScript(scriptName: string): boolean;
  protected init(): Promise<void>;
  private createDefaultNpmPackage;
}
export {};
