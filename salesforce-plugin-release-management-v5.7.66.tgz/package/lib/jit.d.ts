type Options = {
    jsonEnabled: boolean;
    jitPlugin?: string[];
    executable: string;
    manifestPath?: string;
};
export declare function testJITInstall(options: Options): Promise<void>;
export {};
