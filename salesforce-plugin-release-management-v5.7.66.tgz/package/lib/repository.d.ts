import { Ux } from '@salesforce/sf-plugins-core';
import shelljs from 'shelljs';
import { AsyncOptionalCreatable, Env } from '@salesforce/kit';
import { Package } from './package.js';
import { Registry } from './registry.js';
import { SigningResponse } from './codeSigning/SimplifiedSigning.js';
export type Access = 'public' | 'restricted';
type PublishOpts = {
    dryrun?: boolean;
    signatures?: SigningResponse[];
    tag?: string;
    access?: Access;
};
export type PackageInfo = {
    name: string;
    nextVersion: string;
    registryParam: string;
};
type PollFunction = () => boolean;
type RepositoryOptions = {
    ux: Ux;
    useprerelease?: string;
    useoidc?: boolean;
};
declare abstract class Repository extends AsyncOptionalCreatable<RepositoryOptions> {
    protected options?: RepositoryOptions;
    protected ux: Ux;
    protected env: Env;
    protected registry: Registry;
    private stepCounter;
    constructor(options: RepositoryOptions | undefined);
    install(silent?: boolean): void;
    build(silent?: boolean): void;
    run(script: string, location?: string, silent?: boolean): void;
    test(): void;
    printStage(msg: string): void;
    writeNpmToken(): Promise<void>;
    protected execCommand(cmd: string, silent?: boolean): shelljs.ShellString;
    protected poll(checkFn: PollFunction): Promise<boolean>;
    abstract getSuccessMessage(): string;
    abstract getPkgInfo(packageNames?: string[]): PackageInfo | PackageInfo[];
    abstract publish(options: PublishOpts): Promise<void>;
    abstract sign(packageNames?: string[]): Promise<SigningResponse | SigningResponse[]>;
    abstract waitForAvailability(): Promise<boolean>;
    protected abstract init(): Promise<void>;
}
export declare class PackageRepo extends Repository {
    name: string;
    nextVersion: string;
    package: Package;
    private logger;
    constructor(options: RepositoryOptions | undefined);
    sign(): Promise<SigningResponse>;
    revertChanges(): Promise<void>;
    getPkgInfo(): PackageInfo;
    publish(opts?: PublishOpts): Promise<void>;
    waitForAvailability(): Promise<boolean>;
    getSuccessMessage(): string;
    protected init(): Promise<void>;
    private determineNextVersion;
}
export {};
