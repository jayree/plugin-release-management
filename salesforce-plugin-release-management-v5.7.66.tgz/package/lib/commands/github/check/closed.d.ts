import { SfCommand } from '@salesforce/sf-plugins-core';
type GithubCheckClosedResultItem = {
  issueUrl: string;
  status: string;
  workItem: string;
};
export type GithubCheckClosedResult = GithubCheckClosedResultItem[];
export default class GithubCheckClosed extends SfCommand<GithubCheckClosedResult> {
  static readonly summary: string;
  static readonly description: string;
  static readonly examples: string[];
  static readonly flags: {
    gus: import('@oclif/core/interfaces').OptionFlag<
      import('@salesforce/core').Org,
      import('@oclif/core/interfaces').CustomOptions
    >;
    'github-token': import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
  };
  run(): Promise<GithubCheckClosedResult>;
}
export {};
