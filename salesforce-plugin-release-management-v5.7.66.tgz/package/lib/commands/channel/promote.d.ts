import { Interfaces } from '@oclif/core';
import { SfCommand } from '@salesforce/sf-plugins-core';
import { CLI } from '../../types.js';
export type PromoteResult = {
    dryRun: boolean;
    cli: CLI;
    target: string;
    sha: string;
    version: string;
    platforms: string[];
};
export default class Promote extends SfCommand<PromoteResult> {
    static readonly description: string;
    static readonly summary: string;
    static readonly examples: string[];
    static readonly flags: {
        dryrun: Interfaces.BooleanFlag<boolean>;
        'promote-to-channel': Interfaces.OptionFlag<string, Interfaces.CustomOptions>;
        'promote-from-channel': Interfaces.OptionFlag<string | undefined, Interfaces.CustomOptions>;
        platform: Interfaces.OptionFlag<string[] | undefined, Interfaces.CustomOptions>;
        cli: Interfaces.OptionFlag<CLI, Interfaces.CustomOptions>;
        sha: Interfaces.OptionFlag<string | undefined, Interfaces.CustomOptions>;
        'max-age': Interfaces.OptionFlag<number, Interfaces.CustomOptions>;
        indexes: Interfaces.BooleanFlag<boolean>;
        xz: Interfaces.BooleanFlag<boolean>;
        'architecture-target': Interfaces.OptionFlag<string[] | undefined, Interfaces.CustomOptions>;
        version: Interfaces.OptionFlag<string | undefined, Interfaces.CustomOptions>;
    };
    private flags;
    run(): Promise<PromoteResult>;
    /**
     * validate flag combinations
     *
     * @private
     */
    private validateFlags;
}
