import { Operation } from 'just-diff';
import { SfCommand } from '@salesforce/sf-plugins-core';
import { JsonMap } from '@salesforce/ts-types';
import { Interfaces } from '@oclif/core';
export type ArtifactsCompareResult = {
  [plugin: string]: {
    current: {
      version: string | null;
      snapshot: CommandSnapshot[];
      schemas: Record<string, JsonMap>;
    };
    previous: {
      version: string | null;
      snapshot: CommandSnapshot[];
      schemas: Record<string, JsonMap>;
    };
    snapshotChanges: SnapshotChanges;
    schemaChanges: SchemaChanges;
  };
};
type CommandSnapshot = {
  command: string;
  plugin: string;
  flags: string[];
  alias: string[];
  args?: string[];
};
type SnapshotChanges = {
  commandAdditions: string[];
  commandRemovals: string[];
  commands: Array<{
    command: string;
    aliasAdditions: string[];
    aliasRemovals: string[];
    flagAdditions: string[];
    flagRemovals: string[];
    hasChanges: boolean;
    hasBreakingChanges: boolean;
  }>;
  hasChanges: boolean;
  hasBreakingChanges: boolean;
};
type SchemaChanges = Array<{
  op: Operation;
  path: Array<string | number>;
  value: unknown;
}>;
export declare class SnapshotComparator {
  current: CommandSnapshot[];
  previous: CommandSnapshot[];
  constructor(current: CommandSnapshot[], previous: CommandSnapshot[]);
  getChanges(): SnapshotChanges;
  getCommandAdditions(): string[];
  getCommandRemovals(): string[];
  getFlagAdditions(cmd: string): string[];
  getFlagRemovals(cmd: string): string[];
  getAliasAdditions(cmd: string): string[];
  getAliasRemovals(cmd: string): string[];
}
export declare class SchemaComparator {
  private current;
  private previous;
  constructor(current: Record<string, JsonMap>, previous: Record<string, JsonMap>);
  static makeReadable(
    current: Record<string, JsonMap>,
    previous: Record<string, JsonMap>,
    changes: SchemaChanges
  ): Record<string, string[]>;
  static hasBreakingChange(changes: SchemaChanges): boolean;
  private static isMeaningless;
  getChanges(): SchemaChanges;
}
export default class ArtifactsTest extends SfCommand<ArtifactsCompareResult> {
  static readonly summary: string;
  static readonly examples: string[];
  static readonly flags: {
    plugin: Interfaces.OptionFlag<string[] | undefined, Interfaces.CustomOptions>;
    previous: Interfaces.OptionFlag<string | undefined, Interfaces.CustomOptions>;
    current: Interfaces.OptionFlag<string | undefined, Interfaces.CustomOptions>;
  };
  private octokit;
  private currentPlugins;
  private previousPlugins;
  private flags;
  private packageJson;
  private versions;
  private current;
  private previous;
  run(): Promise<ArtifactsCompareResult>;
  private showResults;
  private showRemovedPlugins;
  private showAddedPlugins;
  private resolveVersions;
  private getCurrentPlugins;
  private getPluginsForVersion;
  private filterPlugins;
  private getVersions;
  private getSchemas;
  private getSnapshot;
  private getTags;
}
export {};
