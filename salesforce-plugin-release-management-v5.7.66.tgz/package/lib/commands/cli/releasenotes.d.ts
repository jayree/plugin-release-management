import { SfCommand } from '@salesforce/sf-plugins-core';
type Change = {
  author: string;
  description: string;
  link: string;
  mergedAt: string;
  mergedInto: string;
  plugin: string;
  title: string;
};
export type ChangesByPlugin = Record<string, Change[]>;
export default class ReleaseNotes extends SfCommand<ChangesByPlugin> {
  static readonly summary: string;
  static readonly description: string;
  static readonly examples: string[];
  static readonly flags: {
    cli: import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
    since: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
    markdown: import('@oclif/core/interfaces').BooleanFlag<boolean>;
  };
  private octokit;
  private usernames;
  run(): Promise<ChangesByPlugin>;
  private getNameOfUser;
  private getPullsForPlugin;
  private logChanges;
  private logChangesMarkdown;
}
export {};
