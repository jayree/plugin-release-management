import { SfCommand } from '@salesforce/sf-plugins-core';
export default class Test extends SfCommand<void> {
  static readonly summary: string;
  static readonly examples: string[];
  static readonly flags: {
    'jit-plugin': import('@oclif/core/interfaces').OptionFlag<
      string[] | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
  };
  run(): Promise<void>;
}
