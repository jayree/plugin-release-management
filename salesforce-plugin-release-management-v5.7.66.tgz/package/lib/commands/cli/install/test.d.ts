import { SfCommand } from '@salesforce/sf-plugins-core';
export default class Test extends SfCommand<void> {
  static readonly description: string;
  static readonly summary: string;
  static readonly examples: string[];
  static readonly flags: {
    cli: import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
    method: import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
    channel: import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
    'output-file': import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
  };
  run(): Promise<void>;
}
