import { SfCommand } from '@salesforce/sf-plugins-core';
import { Interfaces } from '@oclif/core';
/**
 * The functionality of this command is taken entirely from https://github.com/salesforcecli/sfdx-cli/blob/v7.109.0/scripts/clean-for-tarballs
 */
export default class Prepare extends SfCommand<void> {
  static readonly summary: string;
  static readonly description: string;
  static readonly examples: string[];
  static readonly flags: {
    dryrun: Interfaces.BooleanFlag<boolean>;
    types: Interfaces.BooleanFlag<boolean>;
    verbose: Interfaces.BooleanFlag<boolean>;
  };
  private flags;
  run(): Promise<void>;
  private remove;
}
