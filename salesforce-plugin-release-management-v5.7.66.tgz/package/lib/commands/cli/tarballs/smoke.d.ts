import { SfCommand } from '@salesforce/sf-plugins-core';
import { Interfaces } from '@oclif/core';
export default class SmokeTest extends SfCommand<void> {
    static readonly summary: string;
    static readonly description: string;
    static readonly examples: string[];
    static readonly flags: {
        verbose: Interfaces.BooleanFlag<boolean>;
    };
    private flags;
    run(): Promise<void>;
    private smokeTest;
    private testJITInstall;
    private testInstall;
    private verifyInstall;
    private initializeAllCommands;
    private getAllCommands;
    private nonVerboseCommandExecution;
    private execute;
}
