import { SfCommand } from '@salesforce/sf-plugins-core';
import { Interfaces } from '@oclif/core';
import { CLI } from '../../../types.js';
/**
 * The functionality of this command is taken entirely from https://github.com/salesforcecli/sfdx-cli/blob/v7.109.0/scripts/verify-tarballs
 */
export default class Verify extends SfCommand<void> {
    static readonly summary: string;
    static readonly description: string;
    static readonly examples: string[];
    static readonly flags: {
        cli: Interfaces.OptionFlag<CLI, Interfaces.CustomOptions>;
        "windows-username-buffer": Interfaces.OptionFlag<number, Interfaces.CustomOptions>;
    };
    private baseDir;
    private step;
    private totalSteps;
    private flags;
    run(): Promise<void>;
    execute(msg: string, validate: () => Promise<boolean>): Promise<boolean>;
    ensureNoWebDriverIO(): Promise<void>;
    ensureNoHerokuCliUtilNyc(): Promise<void>;
    /**
     * Ensure that the path lengths in the build tree are as windows safe as possible.
     *
     * The check fails if the path lengths DO NOT allow for a username longer than the --windows-username-buffer
     *
     * Warnings will be emitted for any path that does not allow for a username longer than 48 characters
     */
    ensureWindowsPathLengths(): Promise<void>;
    ensureApexNode(): Promise<void>;
    ensureTemplatesCommands(): Promise<void>;
    ensureNoDistTestsOrMaps(): Promise<void>;
    ensureNoUnexpectedFiles(): Promise<void>;
    ensureMdMessagesExist(): Promise<void>;
    ensureSfIsIncluded(): Promise<void>;
}
