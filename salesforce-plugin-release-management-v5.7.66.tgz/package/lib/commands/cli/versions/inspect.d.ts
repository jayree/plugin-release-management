import { SfCommand } from '@salesforce/sf-plugins-core';
import { Interfaces } from '@oclif/core';
export type Info = {
  origin: string;
  version: string;
  channel: Channel;
  location: Location;
  dependencies: Dependency[];
};
export type InspectResult = Info[];
export type Dependency = {
  name: string;
  version: string;
};
export declare enum Channel {
  STABLE = 'stable',
  STABLE_RC = 'stable-rc',
  LATEST = 'latest',
  LATEST_RC = 'latest-rc',
  NIGHTLY = 'nightly',
}
export declare enum Location {
  ARCHIVE = 'archive',
  NPM = 'npm',
}
type ArchiveChannel = Extract<Channel, Channel.STABLE | Channel.STABLE_RC | Channel.NIGHTLY>;
type Archives = Record<ArchiveChannel, string[]>;
export default class Inspect extends SfCommand<InspectResult> {
  static readonly summary: string;
  static readonly description: string;
  static readonly examples: string[];
  static readonly flags: {
    dependencies: Interfaces.OptionFlag<string[] | undefined, Interfaces.CustomOptions>;
    salesforce: Interfaces.BooleanFlag<boolean>;
    channels: Interfaces.OptionFlag<string[], Interfaces.CustomOptions>;
    locations: Interfaces.OptionFlag<string[], Interfaces.CustomOptions>;
    'ignore-missing': Interfaces.BooleanFlag<boolean>;
  };
  workingDir: string;
  archives?: Archives;
  private flags;
  run(): Promise<InspectResult>;
  private initArchives;
  private inspectArchives;
  private inspectNpm;
  private getDependencies;
  private logResults;
}
export {};
