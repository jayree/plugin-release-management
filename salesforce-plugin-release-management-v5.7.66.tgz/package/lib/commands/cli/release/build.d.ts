import { SfCommand } from '@salesforce/sf-plugins-core';
export default class build extends SfCommand<void> {
    static readonly description: string;
    static readonly summary: string;
    static readonly examples: string[];
    static readonly aliases: string[];
    static readonly flags: {
        'start-from-npm-dist-tag': import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        'start-from-github-ref': import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        'release-channel': import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
        'build-only': import("@oclif/core/interfaces").BooleanFlag<boolean>;
        resolutions: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        only: import("@oclif/core/interfaces").OptionFlag<string[] | undefined, import("@oclif/core/interfaces").CustomOptions>;
        'pinned-deps': import("@oclif/core/interfaces").BooleanFlag<boolean>;
        jit: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        label: import("@oclif/core/interfaces").OptionFlag<string[] | undefined, import("@oclif/core/interfaces").CustomOptions>;
        patch: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        empty: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        'pr-base-branch': import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
    };
    run(): Promise<void>;
    private distTagToGithubRef;
    private createAndPushBaseBranch;
    private exec;
    private maybeSetGitConfig;
}
