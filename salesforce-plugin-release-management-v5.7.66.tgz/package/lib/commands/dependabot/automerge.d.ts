import { SfCommand } from '@salesforce/sf-plugins-core';
export default class AutoMerge extends SfCommand<void> {
  static readonly summary: string;
  static readonly description: string;
  static readonly examples: string[];
  static readonly flags: {
    owner: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
    repo: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
    'max-version-bump': import('@oclif/core/interfaces').OptionFlag<
      string,
      import('@oclif/core/interfaces').CustomOptions
    >;
    dryrun: import('@oclif/core/interfaces').BooleanFlag<boolean>;
    'skip-ci': import('@oclif/core/interfaces').BooleanFlag<boolean>;
    'merge-method': import('@oclif/core/interfaces').OptionFlag<string, import('@oclif/core/interfaces').CustomOptions>;
  };
  private octokit;
  private baseRepoObject;
  run(): Promise<void>;
  private isGreen;
  private isMergeable;
}
