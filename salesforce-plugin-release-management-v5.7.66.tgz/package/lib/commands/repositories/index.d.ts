import { SfCommand } from '@salesforce/sf-plugins-core';
import { RepositoryInfo } from '../../repositories.js';
export type RepositoryResult = RepositoryInfo[];
export default class Repositories extends SfCommand<RepositoryResult> {
  static readonly summary: string;
  static readonly description: string;
  static readonly examples: string[];
  static readonly flags: {
    columns: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
    csv: import('@oclif/core/interfaces').BooleanFlag<boolean>;
    extended: import('@oclif/core/interfaces').BooleanFlag<boolean>;
    filter: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
    'no-header': import('@oclif/core/interfaces').BooleanFlag<boolean>;
    'no-truncate': import('@oclif/core/interfaces').BooleanFlag<boolean>;
    output: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
    sort: import('@oclif/core/interfaces').OptionFlag<
      string | undefined,
      import('@oclif/core/interfaces').CustomOptions
    >;
  };
  run(): Promise<RepositoryResult>;
}
