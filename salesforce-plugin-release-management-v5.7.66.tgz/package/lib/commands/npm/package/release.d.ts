import { SfCommand } from '@salesforce/sf-plugins-core';
import { PackageInfo } from '../../../repository.js';
export type ReleaseResult = {
    version: string;
    name: string;
};
export default class Release extends SfCommand<ReleaseResult> {
    static readonly summary: string;
    static readonly description: string;
    static readonly flags: {
        dryrun: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        sign: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        npmtag: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
        npmaccess: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
        install: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        prerelease: import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        verify: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        githubtag: import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        oidc: import("@oclif/core/interfaces").BooleanFlag<boolean>;
    };
    run(): Promise<ReleaseResult>;
    protected verifySign(pkgInfo: PackageInfo): void;
}
