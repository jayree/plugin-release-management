import { SfCommand } from '@salesforce/sf-plugins-core';
import { ChangedPackageVersions } from '../../../package.js';
export default class Pin extends SfCommand<ChangedPackageVersions> {
    static readonly summary: string;
    static readonly description: string;
    static readonly flags: {
        dryrun: import("@oclif/core/interfaces").BooleanFlag<boolean>;
        tag: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
    };
    run(): Promise<ChangedPackageVersions>;
}
