import { OutputFlags } from '@oclif/core/parser';
type Flags = OutputFlags<any>;
type ConditionFn = (flags: Flags) => boolean;
type DependencyType = 'env';
type Dependency = {
    name: string;
    type: DependencyType;
    condition?: ConditionFn;
};
type Result = {
    name: string;
    type: DependencyType;
    passed: boolean;
    message?: string;
};
/**
 *
 * @param args that flags being validated
 * @param depFilter a filter function that runs on the above DEPENDENCIES
 * @param condition a function that runs on the args
 * @returns
 */
export declare function verifyDependencies<A extends Flags>(args: A, depFilter?: (dep: Dependency) => boolean, condition?: (a: A) => boolean): {
    failures: number;
    results: Result[];
};
export {};
