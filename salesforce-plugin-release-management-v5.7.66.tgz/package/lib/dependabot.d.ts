export declare const maxVersionBumpFlag: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
export declare const getOwnerAndRepo: (ownerFlag?: string, repoFlag?: string) => Promise<{
    owner: string;
    repo: string;
}>;
