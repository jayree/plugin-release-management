import { PackageJsonSfdxProperty } from '../package.js';
export declare const BASE_URL = 'https://developer.salesforce.com';
export declare const SECURITY_PATH = 'media/salesforce-cli/security';
type SigningRequest = {
  /** path to the file on local FS */
  targetFileToSign: string;
  /** npm name, including namespace */
  packageName: string;
  /** npm version */
  packageVersion: string;
  /** if true, uploads the signature and key file to AWS */
  upload: boolean;
};
export type SigningResponse = {
  publicKeyContents: string;
  signatureContents: string;
  /**
   * matches this pattern for npm meta
   * "sfdx": {
   * "publicKeyUrl": "https://developer.salesforce.com/media/salesforce-cli/sfdx-cli-03032020.crt",
   * "signatureUrl": "https://developer.salesforce.com/media/salesforce-cli/signatures/salesforce-plugin-user-1.3.0.sig"
   * },
   */
  packageJsonSfdxProperty: PackageJsonSfdxProperty;
  fileTarPath: string;
  /** npm name, including namespace */
  packageName: string;
  /** npm version, like 1.0.0 */
  packageVersion: string;
};
export declare const getSfdxProperty: (packageName: string, packageVersion: string) => PackageJsonSfdxProperty;
export declare const signVerifyUpload: (signingRequest: SigningRequest) => Promise<SigningResponse>;
export {};
