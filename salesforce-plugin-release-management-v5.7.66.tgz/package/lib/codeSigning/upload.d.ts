import AWS from 'aws-sdk';
export declare function putObject(bucket: string, key: string, body: string): Promise<AWS.S3.PutObjectOutput>;
