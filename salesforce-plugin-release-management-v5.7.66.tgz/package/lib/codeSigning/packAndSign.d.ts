#!/usr/bin/env node
import { Agents } from 'got';
import { Ux } from '@salesforce/sf-plugins-core';
import { PackageJson } from '../package.js';
import { SigningResponse } from './SimplifiedSigning.js';
export declare const api: {
  setUx(ux: Ux): void;
  /**
   * call out to npm pack;
   */
  pack(): Promise<string>;
  /**
   * read the package.json file for the target npm to be signed.
   */
  retrievePackageJson(): Promise<string>;
  /**
   * read the npm ignore file for the target npm
   *
   * @param filename - local path to the npmignore file
   */
  retrieveIgnoreFile(filename: string): Promise<string>;
  /**
   * checks the ignore content for the code signing patterns. *.tgz, *.sig package.json.bak
   *
   * @param content
   */
  validateNpmIgnorePatterns(content: string): void;
  /**
   * checks the ignore content for the code signing patterns. *.tgz, *.sig package.json.bak
   *
   * @param content
   */
  validateNpmFilePatterns(patterns: string[]): void;
  /**
   * makes a backup copy pf package.json
   *
   * @param src - the package.json to backup
   * @param dest - package.json.bak
   */
  copyPackageDotJson(src: string, dest: string): Promise<void>;
  /**
   * used to update the contents of package.json
   *
   * @param pJson - the updated json content to write to disk
   */
  writePackageJson(pJson: PackageJson): Promise<void>;
  revertPackageJsonIfExists(): Promise<void>;
  /**
   * main method to pack and sign an npm.
   *
   * @param args - reference to process.argv
   * @param ux - The cli ux interface usually provided by oclif.
   * @return {Promise<SigningResponse>} The SigningResponse
   */
  packSignVerifyModifyPackageJSON(targetPackagePath: string): Promise<SigningResponse>;
  getAgentForUri(url: string): false | Agents;
};
