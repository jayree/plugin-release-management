type SourcePackageDefinition = {
    name: string;
    type: 'package' | 'library' | 'orb';
};
type SourceRepositoryDefinition = {
    url: string;
    packages: SourcePackageDefinition[];
};
export type RepositoryInfo = {
    organization: string;
    name: string;
} & SourceRepositoryDefinition;
/**
 * Get a list of known tooling repositories that include Salesforce CLI plugins, libraries, and orbs.
 */
export declare const retrieveKnownRepositories: () => Promise<RepositoryInfo[]>;
export {};
